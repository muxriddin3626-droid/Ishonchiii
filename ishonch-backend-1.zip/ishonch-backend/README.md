# ISHONCH SMS Backend

100,000+ foydalanuvchi uchun mo'ljallangan, navbat (queue) asosidagi SMS yuborish tizimi.

## Qanday ishlaydi

```
Ilova → Backend (/api/sms/queue) → Supabase (sms_queue jadvali)
                                          ↓
                    Worker (har 5 soniyada, 20 tadan batch)
                                          ↓
                                    Eskiz.uz API
```

- Foydalanuvchi SMS yuborganda, ilova **darhol javob oladi** ("navbatga qo'yildi") — qotib qolmaydi
- Fon worker har 5 soniyada navbatdan 20 tagacha SMS oladi va Eskiz orqali yuboradi
- Eskiz limitidan oshmaslik uchun SMS orasida 150ms kutiladi
- Xato bo'lsa (masalan noto'g'ri raqam) — o'sha SMS "failed" bo'ladi, qolganlari davom etadi

## O'rnatish

### 1. Supabase'da jadval yaratish
`sms_queue_schema.sql` faylini Supabase SQL Editor'da ishga tushiring.

Bundan tashqari, `shops` jadvalingizda `sms_used` ustuni yo'q bo'lsa qo'shing:
```sql
ALTER TABLE shops ADD COLUMN IF NOT EXISTS sms_used INTEGER DEFAULT 0;
```

### 2. Eskiz.uz ma'lumotlari
`.env.example` dan nusxa olib `.env` yarating, quyidagilarni to'ldiring:
- `SUPABASE_URL` — loyihangiz URL'i
- `SUPABASE_SERVICE_KEY` — Supabase Dashboard → Settings → API → **service_role** key (anon emas!)
- `ESKIZ_EMAIL`, `ESKIZ_PASSWORD` — Eskiz.uz hisobingiz

### 3. Railway'ga deploy qilish
1. GitHub'ga shu papkani yuklang (yangi repo, masalan `ishonch-backend`)
2. [railway.app](https://railway.app) → "New Project" → "Deploy from GitHub repo"
3. Repo'ni tanlang
4. "Variables" bo'limida `.env` dagi barcha qiymatlarni qo'shing
5. Deploy tugagach, Railway sizga URL beradi (masalan `ishonch-backend-production.up.railway.app`)

### 4. Frontend (Ishonch_v3.jsx) bilan ulash
Ilovada SMS yuborish joylarida, hozirgi soxta (`setTimeout`) o'rniga backend'ga so'rov yuborish kerak:

```javascript
const BACKEND_URL = "https://sizning-backend.up.railway.app";

async function sendSmsToQueue(phone, message, shopId, kind) {
  const res = await fetch(BACKEND_URL + "/api/sms/queue", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone, message, shopId, kind }),
  });
  return res.json();
}
```

Buni alohida qadamda ilova kodiga qo'shib beraman — backend tayyor bo'lgach ayting.

## API Endpoints

| Method | Path | Tavsif |
|--------|------|--------|
| POST | `/api/sms/queue` | Bitta SMS navbatga qo'yish |
| POST | `/api/sms/queue-bulk` | Ko'p SMS bir vaqtda (Admin broadcast) |
| GET | `/api/sms/status/:id` | SMS holatini tekshirish |
| GET | `/api/sms/stats/:shopId` | Do'kon yuborgan SMS soni |
| GET | `/health` | Server ishlab turganini tekshirish |

## Nazorat

Supabase'da `sms_queue` jadvalini ko'rib turib:
- `status = 'pending'` — navbatda kutmoqda
- `status = 'sending'` — hozir yuborilmoqda
- `status = 'sent'` — muvaffaqiyatli yuborildi
- `status = 'failed'` — xato (error_msg ustunida sababi)

## Xavfsizlik sozlash (MUHIM!)

### 1. Admin parolini xavfsiz qilish
Terminalda (yoki Railway'ning "Shell" bo'limida):
```
node scripts/hash-password.js "sizning_kuchli_parolingiz"
```
Chiqqan hash'ni `.env` dagi `ADMIN_PASS_HASH` ga qo'ying. `ADMIN_LOGIN` ga o'zingiz xohlagan login yozing.

### 2. JWT_SECRET
`.env` dagi `JWT_SECRET` ni kamida 32 ta tasodifiy belgidan iborat satrga o'zgartiring. Masalan:
```
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### 3. Supabase RLS (Row Level Security)
`supabase_security_setup.sql` faylini Supabase SQL Editor'da ishga tushiring. Bu:
- Har bir do'kon faqat o'z ma'lumotlarini ko'rishini ta'minlaydi
- Supabase Auth'ga o'tkazadi (parollar endi xavfsiz, bcrypt bilan Supabase tomonidan boshqariladi)

### 4. Admin panel frontend sozlash
`Ishonch_Admin.jsx` faylida:
```javascript
const BACKEND_URL = "https://sizning-backend.up.railway.app";
```
qatorini haqiqiy Railway URL'ingiz bilan almashtiring.

## Xavfsizlik nima uchun muhim edi

| Muammo | Oldin | Endi |
|---|---|---|
| Admin parol | Frontend kodda ochiq matn | Backendда bcrypt hash, hech qachon frontendga chiqmaydi |
| Foydalanuvchi parollari | localStorage/oddiy baza, shifrlanmagan | Supabase Auth (bcrypt, sanoat standarti) |
| Boshqa do'kon ma'lumotini ko'rish | RLS yo'q edi - har kim hammasini ko'rishi mumkin edi | RLS - faqat o'z ma'lumotlaringiz |
| Admin login hujumi | Cheksiz urinish mumkin edi | Rate-limit: 5 urinishdan keyin 30 daqiqa blok |



Hozirgi sozlama: 20 SMS/5 soniya = ~240 SMS/daqiqa = ~14,400 SMS/soat.
Agar kerak bo'lsa `server.js` dagi `SMS_PER_BATCH` va `BATCH_INTERVAL_MS` qiymatlarini oshiring — lekin Eskiz.uz tarifingizdagi limitdan oshmasligiga ishonch hosil qiling.
